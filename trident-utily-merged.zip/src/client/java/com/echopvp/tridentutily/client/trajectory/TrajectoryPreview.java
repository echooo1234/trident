package com.echopvp.tridentutily.client.trajectory;

import com.echopvp.tridentutily.client.config.TridentConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Yörünge önizlemesi: düşük seviye render pipeline'ı yerine istemci tarafı parçacıklarla çizilir.
 * Fırlatılan trident'in izlediği yol, her birkaç tick'te parçacık noktalarıyla gösterilir.
 */
public final class TrajectoryPreview {
	private static final double SPEED = 2.5;
	private static final double GRAVITY = 0.05;
	private static final double DRAG = 0.99;

	private static final ParticleOptions PATH_PARTICLE = ParticleTypes.CRIT;
	private static final ParticleOptions END_PARTICLE = ParticleTypes.END_ROD;

	private static int tickCounter;

	private TrajectoryPreview() {
	}

	public static void register() {
		ClientTickEvents.END_CLIENT_TICK.register(TrajectoryPreview::onTick);
	}

	public static ItemStack findTrident(LocalPlayer player) {
		ItemStack main = player.getMainHandItem();
		if (main.is(Items.TRIDENT)) {
			return main;
		}
		ItemStack off = player.getOffhandItem();
		if (off.is(Items.TRIDENT)) {
			return off;
		}
		return ItemStack.EMPTY;
	}

	private static void onTick(Minecraft mc) {
		TridentConfig cfg = TridentConfig.get();
		LocalPlayer player = mc.player;
		if (!cfg.trajectoryEnabled || player == null || mc.level == null || mc.isPaused()) {
			return;
		}

		if (++tickCounter % 2 != 0) {
			return;
		}

		ItemStack stack = findTrident(player);
		if (stack.isEmpty()) {
			return;
		}

		// Riptide'lı trident fırlatılmaz, yörünge göstermenin anlamı yok.
		if (EnchantmentHelper.getTridentSpinAttackStrength(stack, player) > 0) {
			return;
		}

		if (!cfg.trajectoryWhileHeld && !player.isUsingItem()) {
			return;
		}

		List<Vec3> points = simulate(mc, player, cfg.trajectoryMaxSteps);
		for (int i = 0; i < points.size(); i += 3) {
			Vec3 p = points.get(i);
			mc.level.addParticle(PATH_PARTICLE, p.x, p.y, p.z, 0, 0, 0);
		}

		if (points.size() > 1) {
			Vec3 end = points.get(points.size() - 1);
			mc.level.addParticle(END_PARTICLE, end.x, end.y, end.z, 0, 0, 0);
		}
	}

	private static List<Vec3> simulate(Minecraft mc, LocalPlayer player, int maxSteps) {
		List<Vec3> points = new ArrayList<>();

		Vec3 pos = player.getEyePosition().subtract(0, 0.1, 0);
		Vec3 vel = player.getViewVector(1.0F).scale(SPEED);
		Vec3 pv = player.getDeltaMovement();
		vel = vel.add(pv.x, player.onGround() ? 0.0 : pv.y, pv.z);

		points.add(pos);
		for (int i = 0; i < maxSteps; i++) {
			Vec3 next = pos.add(vel);
			var hit = mc.level.clip(new ClipContext(
				pos, next,
				ClipContext.Block.COLLIDER,
				ClipContext.Fluid.NONE,
				player
			));
			if (hit.getType() != HitResult.Type.MISS) {
				points.add(hit.getLocation());
				break;
			}
			points.add(next);
			pos = next;
			vel = vel.scale(DRAG).add(0, -GRAVITY, 0);
		}
		return points;
	}
}
