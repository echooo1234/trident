package com.echopvp.tridentutily.client.hud;

import com.echopvp.tridentutily.client.config.TridentConfig;
import com.echopvp.tridentutily.client.trajectory.TrajectoryPreview;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

public final class TridentHud {
	private TridentHud() {
	}

	public static void register() {
		HudElementRegistry.attachElementBefore(
			VanillaHudElements.CHAT,
			Identifier.fromNamespaceAndPath("trident-utily", "trident_hud"),
			TridentHud::render
		);
	}

	private static void render(GuiGraphics graphics, DeltaTracker tickCounter) {
		TridentConfig cfg = TridentConfig.get();
		if (!cfg.hudEnabled) {
			return;
		}

		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (player == null || mc.options.hideGui) {
			return;
		}

		ItemStack stack = TrajectoryPreview.findTrident(player);
		if (stack.isEmpty()) {
			return;
		}

		boolean riptide = EnchantmentHelper.getTridentSpinAttackStrength(stack, player) > 0;
		boolean wet = player.isInWaterOrRain();

		int x = 8;
		int y = 8;
		int step = 11;

		graphics.drawString(mc.font, "Trident Util", x, y, 0xFF55FFFF, true);
		y += step;
		graphics.drawString(mc.font, "Riptide: " + (riptide ? "var" : "yok"), x, y, 0xFFFFFFFF, true);
		y += step;

		if (riptide) {
			graphics.drawString(mc.font,
				"Su / yağmur: " + (wet ? "evet (fırlatılabilir)" : "hayır (fırlatılamaz)"),
				x, y, wet ? 0xFF55FF55 : 0xFFFF5555, true);
			y += step;
			graphics.drawString(mc.font,
				String.format("Boost çarpanı: x%.2f%s", cfg.boostMultiplier, cfg.boostEnabled ? "" : " (kapalı)"),
				x, y, 0xFFFFFFFF, true);
			y += step;
			if (player.isAutoSpinAttack()) {
				graphics.drawString(mc.font, "Riptide aktif", x, y, 0xFFFFFF55, true);
			}
		}
	}
}
