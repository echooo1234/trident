package com.echopvp.tridentutily.client.mixin;

import com.echopvp.tridentutily.client.config.TridentConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(TridentItem.class)
public class TridentItemMixin {

	/**
	 * Riptide fırlatması uygulandıktan sonra istemci oyuncusunun hızını ayarlanan çarpanla ölçekler.
	 * Yalnızca yerel (singleplayer / LAN'a açık) dünyada çalışır.
	 */
	@Inject(method = "releaseUsing", at = @At("RETURN"))
	private void tridentutil$boost(ItemStack stack, Level level, LivingEntity entity, int timeLeft, CallbackInfoReturnable<Boolean> cir) {
		if (!level.isClientSide() || !(entity instanceof Player player)) {
			return;
		}

		TridentConfig cfg = TridentConfig.get();
		if (!cfg.boostEnabled || cfg.boostMultiplier <= 1.0f) {
			return;
		}

		Minecraft mc = Minecraft.getInstance();
		if (mc.getSingleplayerServer() == null || player != mc.player) {
			return;
		}

		if (!player.isAutoSpinAttack()) {
			return;
		}

		player.setDeltaMovement(player.getDeltaMovement().scale(cfg.boostMultiplier));
	}
}
