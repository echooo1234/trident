# Trident Util (Fabric 1.21.11, Mojang mappings)

Singleplayer / LAN'a açık dünyalar için istemci taraflı trident yardımcı modu.

## Özellikler
- **Yörünge önizleme:** Trident'i fırlatırken (veya elde tutarken) gideceği yolu parçacık noktalarıyla, düşeceği yeri END_ROD parçacığıyla gösterir.
- **Riptide HUD:** Riptide var mı, su/yağmur şartı sağlanıyor mu, aktif mi, boost çarpanı kaç.
- **Riptide boost çarpanı:** 1.0x - 5.0x arası, config menüsünden ayarlanır. Sadece yerel dünyada çalışır.
- **Config menüsü:** F7 ile açılır (Kontroller menüsünden değiştirilebilir). Ayarlar `config/tridentutil.json` dosyasına kaydedilir.

## Derleme
1. Java 21 gerekli (wrapper şablondan geliyor).
2. `./gradlew build`
3. `build/libs/trident-utily-1.0.0.jar` dosyasını `mods` klasörüne at (Fabric API gerekli).

## Notlar
- 1.21.11 sonrası Yarn güncellenmediği için Mojang mappings kullanılıyor.
- Boost mixin'i `TridentItem.releaseUsing` metoduna bağlanır ve sadece yerel sunucu varken (`getSingleplayerServer() != null`) çalışır.
- Yörünge çizimi 1.21.11'in yeni render pipeline'ıyla uğraşmamak için parçacıkla yapıldı.
- Kod derlenip oyunda denenmedi.
